package easterRaces.entities.cars;

import static easterRaces.common.ExceptionMessages.*;

public abstract class BaseCar implements Car {

    private String model;
    protected int horsePower;
    protected double cubicCentimeters;

    protected BaseCar(String model, int horsePower,double cubicCentimeters) {
        this.setModel(model);
    }

    protected void setModel(String model) {
        if (model.isEmpty() || model.trim().length() < 5){
            throw new IllegalArgumentException(String.format(INVALID_MODEL,getModel(),4));
        }
        this.model = model;
    }


    @Override
    public String getModel() {
        return this.model;
    }

    @Override
    public int getHorsePower() {
        return this.horsePower;
    }

    @Override
    public double getCubicCentimeters() {
        return this.cubicCentimeters;
    }

    @Override
    public double calculateRacePoints(int laps) {
        return (getCubicCentimeters() / getHorsePower()) * laps;
    }
}
